"""Actual mouse pause, resumed deadlines and journal widow-line regressions."""
from pathlib import Path
import json,re
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1];checks=[];errors=[]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);q=b.new_page(viewport={'width':1672,'height':941},service_workers='block');q.set_default_timeout(6000);q.on('pageerror',lambda e:errors.append(str(e)));q.goto('http://127.0.0.1:8010');q.get_by_role('button',name='BEGIN INVESTIGATION').click();q.evaluate('nextIntro();nextIntro();nextIntro();add("Flashlight");add("Field Medkit");S.enemyActors.forEach(a=>a.hp=0);WardWinter.enemies.project();S.pursuer.active=false;S.f.blackoutCount=2')
 def ev(s):return q.evaluate(s)
 def ready():q.wait_for_function('WardWinter.roomViewRenderer()?.loaded&&!WardWinter.orbit.busy')
 def pause_rect():return q.locator('#wardPauseButton').bounding_box()
 def same_pause_rect(before):
  after=pause_rect();assert before and after and max(abs(after[k]-before[k]) for k in ['x','y','width','height'])<=1,(before,after)
 def close_reader():
  close=q.locator('#m .mh').get_by_role('button',name='Close',exact=True)
  hit=close.evaluate('''e=>{const r=e.getBoundingClientRect(),x=r.left+r.width/2,y=r.top+r.height/2,h=document.elementFromPoint(x,y);return {x,y,ok:h===e||e.contains(h),hit:h?.id||h?.textContent};}''')
  assert hit['ok'],('Reader Close center is covered',hit,pause_rect())
  q.mouse.click(hit['x'],hit['y'])
  assert not q.locator('#m .md').count(),'Actual mouse Close must close the record'
  assert not ev('WardWinter.isPaused()'),'Closing a document must not activate Pause'

 assert not q.locator('#m .modal-pause-button').count();assert q.locator('.nav-list #wardPauseButton').count()==1
 ev('S.room="wardnorth";S.roomViewRoom=null;S.hp=65;S.bat=70;S.lightOn=true;S.f.wet=1;S.f.coldExposure=6;render()');ready()
 q.locator('#wardPauseButton').click();before=ev('[S.t,S.hp,S.san,S.bat,S.f.coldExposure,cnt("Field Medkit")]');ev('advanceTime(5);heal("Field Medkit");useBat("Battery");go("ward");WardWinter.survivalTick()');q.wait_for_timeout(1200);assert ev('WardWinter.isPaused()');assert ev('[S.t,S.hp,S.san,S.bat,S.f.coldExposure,cnt("Field Medkit")]')==before;assert ev('WardSound.snapshot().every(a=>a.paused)');assert ev('S.room')=='wardnorth';q.get_by_role('button',name='Resume game',exact=True).click();q.wait_for_timeout(1100);assert ev('S.hp')<before[1] and ev('S.bat')<before[3];checks.append('mouse Pause freezes health, exposure, battery, movement, inventory and audio; Resume restarts exploration')
 ev('S.f.wet=0;S.f.coldExposure=0;S.f.shivering=0;S.room="security";S.roomViewRoom=null;S.f.power=1;render()');before_reader=pause_rect();ev('doc("Night Attendant Journal")');q.wait_for_timeout(100);same_pause_rect(before_reader);assert not q.locator('#m [data-pause-action]').count();assert q.locator('#wardPauseButton').is_visible();assert ev('WardWinter.reader().pages.length')==1;assert ev('WardWinter.reader().pages[0].endsWith("not mine. not mine. not")');assert ev('parseFloat(getComputedStyle(document.querySelector(".winter-paper-text")).fontSize)')>=20;ev('window.savedRecord=document.querySelector(".record-reader")');q.locator('#wardPauseButton').click();q.get_by_role('button',name='Resume game',exact=True).click();assert ev('window.savedRecord===document.querySelector(".record-reader")');checks.append('the Night Attendant Journal ends on its first readable sheet, and Pause preserves the exact open document')
 close_reader();assert q.locator('.nav-list #wardPauseButton').count()==1;assert not q.locator('#m [data-pause-action]').count()
 ev('S.sceneDisturbance={room:S.room,kind:"body",deadline:Date.now()+1800};S.f.powerOut=1;S.f.powerRestoreReal=Date.now()+1800;S.f.powerRestoreAt=S.t+50;S.pursuer.staggerDeadline=Date.now()+1800');q.locator('#wardPauseButton').click();q.wait_for_timeout(1950);q.get_by_role('button',name='Resume game',exact=True).click();assert ev('S.sceneDisturbance&&S.sceneDisturbance.deadline>Date.now()+600&&S.f.powerRestoreReal>Date.now()+600&&S.pursuer.staggerDeadline>Date.now()+600');checks.append('real-time hallucination, blackout and Subject X stagger deadlines retain their remaining duration across Pause')
 ev('S.sceneDisturbance=null;S.f.powerOut=0;S.pursuer.staggerDeadline=0;S.room="lobby";S.roomView="front";S.roomViewRoom="lobby";render()');ready();ev('WardScene.options.motion=true;WardScene.options.snapMotion=true;WardWinter.orbit.setView("rear");wardPause()');q.wait_for_timeout(250);assert ev('S.roomView')=='front';q.get_by_role('button',name='Resume game',exact=True).click();ready();assert ev('S.roomView')=='rear';checks.append('pausing during a camera fade defers its facing change until Resume')
 q.set_viewport_size({'width':1366,'height':768});ev('doc("Night Attendant Journal")');q.wait_for_timeout(100);assert ev('WardWinter.reader().pages.length')==1;close_reader()
 for width,height in [(1000,800),(390,844)]:
  q.set_viewport_size({'width':width,'height':height});q.wait_for_timeout(100);before_reader=pause_rect();ev('doc("Night Attendant Journal")');q.wait_for_timeout(100);same_pause_rect(before_reader);pages=ev('WardWinter.reader().pages');assert re.sub(r'\s+',' ','\n'.join(pages)).strip()==re.sub(r'\s+',' ',ev('WardWinter.reader().text')).strip()
  for i in range(len(pages)):
   assert ev('(()=>{const n=document.querySelector(".winter-paper-text");return n.scrollHeight<=n.clientHeight+1;})()')
   if i<len(pages)-1:q.get_by_role('button',name='Next document page',exact=True).click()
  q.locator('#wardPauseButton').click();assert q.get_by_role('heading',name='PAUSED',exact=True).is_visible();q.get_by_role('button',name='Resume game',exact=True).click();assert not q.locator('#m [data-pause-action]').count();close_reader();assert q.locator('.nav-list #wardPauseButton').count()==1
 checks.append('tablet/mobile journal retains all text without clipping; mouse Pause retains its exact menu position and never covers the actual mouse Close control')
 assert not errors,errors;b.close()
(ROOT/'tests/results/pause_journal.json').write_text(json.dumps({'checks':checks,'javascript_errors':errors},indent=2)+'\n');print('\n'.join('PASS '+v for v in checks))

/* Finite infected identities and authored nonfatal imaginary combat. */
(function(){
'use strict';
const WW=WardWinter,templates=structuredClone(E);
const edges=r=>Object.entries(D).filter(([id,d])=>(d.a===r||d.b===r)&&doorOpen(id)).map(([,d])=>d.a===r?d.b:d.a);
function route(from,to){const q=[[from]],seen=new Set([from]);while(q.length){const p=q.shift(),r=p.at(-1);if(r===to)return p;for(const next of edges(r))if(!seen.has(next)&&!SAFE_FROM_PURSUER.has(next)){seen.add(next);q.push([...p,next]);}}return [];}
let projected={};
function capture(){if(!S?.enemyActors)return;for(const a of S.enemyActors){if(a.dormant||a.down)continue;if(projected[a.room]===a.id&&Number.isFinite(S.en[a.room]))a.hp=Math.max(0,S.en[a.room]);}}
function project(){if(!S?.enemyActors)return;projected={};S.en={};for(const r of Object.keys(R)){S.en[r]=0;if(templates[r])E[r]=structuredClone(templates[r]);}
 for(const a of S.enemyActors){if(a.id==='window-breach'&&S.f.windowBroken)a.dormant=false;if(a.down&&S.room!==a.room)a.down=false;if(a.dormant||a.hp<=0||a.down)continue;if(projected[a.room])throw Error('Enemy occupancy conflict: '+a.room);projected[a.room]=a.id;S.en[a.room]=a.hp;E[a.room]={n:a.name,hp:a.maxHp,dmg:a.dmg};}
}
function initialize(preserve){if(preserve&&Array.isArray(S.enemyActors)){project();return;}S.enemyActors=S.spawnRooms.map((room,i)=>{const t=templates[room];return {id:'infected-'+i,room,home:room,hp:t.hp,maxHp:t.hp,name:i===0?'Screaming infected orderly':t.n,dmg:t.dmg,type:'infected_patient',screamer:i===0,nextCry:S.t+12,lastMove:S.t,alert:null};});S.enemyActors.push({id:'window-breach',room:'eastcorridor',home:'eastcorridor',hp:7,maxHp:7,name:'Window-breach infected',dmg:[3,6],type:'infected_patient',dormant:true,lastMove:S.t});project();}
const configure=configureWorld;configureWorld=function(seed,preserve=true){if(preserve)capture();for(const [r,t]of Object.entries(templates))E[r]=structuredClone(t);configure(seed,preserve);initialize(preserve);};
function actorAt(room=S.room){capture();return S.enemyActors?.find(a=>!a.dormant&&!a.down&&a.hp>0&&a.room===room);}
function investigate(room,strength=2){capture();if(SAFE_FROM_PURSUER.has(room))return;for(const a of S.enemyActors||[]){if(a.hp<=0||a.dormant||a.down||a.room===room)continue;const p=route(a.room,room);if(p.length>1&&p.length<=strength+1)a.alert={room,expires:S.t+12};}S.f.lastNoise={room,time:S.t,strength};}
function advance(n){if(WW.isPaused?.())return;capture();for(const a of S.enemyActors||[]){if(a.id==='window-breach'&&a.dormant&&S.f.windowBroken){a.dormant=false;a.lastMove=S.t;}
  if(a.hp<=0||a.dormant||a.down)continue;
  if(a.screamer&&a.room===S.room&&S.t>=a.nextCry){a.nextCry=S.t+25;investigate(a.room,1);WardSound?.play('infected_cry',{volume:.5,rate:.9});interaction('The infected releases a hoarse cry. It carries into connected corridors.');}
  if(a.room===S.room)continue;
  if(a.alert&&S.t>=a.alert.expires)a.alert=null;
  const target=a.alert?.room||a.home;if(a.room!==target&&S.t-a.lastMove>=4){const path=route(a.room,target),next=path[1];if(next&&!S.enemyActors.some(b=>b!==a&&!b.dormant&&b.hp>0&&b.room===next)&&!((S.f.pursuerEncounter||S.hallCombat)&&next===S.room)){a.room=next;a.lastMove=S.t;if(next===S.room){soundEffect('escape');interaction('Uneven footsteps reach the doorway. An infected has followed the noise.');}}}
  if(a.screamer&&a.alert&&S.t>=a.nextCry){a.nextCry=S.t+25;investigate(a.room,1);WardSound?.play('infected_cry',{volume:.55,rate:.9});lg('A hoarse cry alerts nearby infected. No new enemies are created.');}
 }project();}
WW.enemies={capture,project,actorAt,investigate,advance,route,snapshot:()=>structuredClone(S.enemyActors||[])};
noise=function(){if(S.pursuer?.active)S.pursuer.noise=Math.min(4,(S.pursuer.noise||0)+2);investigate(S.room,2);lg('The report carries through connected corridors. Anything nearby may hear it.');};
const renderBase=render;render=function(){capture();project();return renderBase();};
const combatBase=combat,shootBase=shoot,meleeBase=knifeAttack,fleeBase=flee,reloadBase=reload,foeBase=foe;
WW.hallActive=()=>!!(S?.hallCombat&&S.hallCombat.room===S.room);
WW.resolveHall=function(reason='wait'){if(!S||S.hp<=0||S.f.dead||!S.hallCombat)return;S.hallCombat=null;S.f.falseEncounterActive=0;S.f.falseEncounterResolved=1;S.f.nextHallucinationAt=S.t+75;cm=0;$('m').innerHTML='';interaction(reason==='damage'?'The figure folds into the shadow. Only the marks on the wall remain. The ammunition I fired was real.':'The figure loses its edges and disappears. No physical injury remains.');lg('The episode ended. It cannot replay in this run.');render();};
function fightPresentation(){WW.orbit?.face('front');document.querySelector('#m .md')?.classList.add('winter-combat-modal');document.querySelector('#m .c1-encounter>img')?.remove();}
WW.fightPresentation=fightPresentation;
function hallCombat(note){const h=S.hallCombat;if(!h)return;cm=1;renderScene();const loaded=W[S.eq]&&has(S.eq)&&(S.ld[S.eq]||0)>0;modal('Infected orderly · approaching',`<div class="c1-encounter"><img src="${WW.asset('assets/characters/infected_patient.png')}" alt="An infected orderly"><div><p>${htmlSafe(note||'It closes the distance, reaching toward my face.')}</p><p>${W[S.eq]&&has(S.eq)?htmlSafe(S.eq)+' · '+(S.ld[S.eq]||0)+' loaded · '+cnt(W[S.eq].ammo)+' reserve':'Unarmed · retreat or create an opening'}</p></div></div><div class="c1-encounter-actions"><button class="btn p" ${loaded?'':'disabled'} onclick="shoot()">Quick shot</button><button class="btn" ${loaded?'':'disabled'} onclick="wardSteadyShot()">Steady aim · takes time</button><button class="btn" onclick="wardStruggle()">Struggle · risk injury</button>${has('Utility Knife')?'<button class="btn" onclick="knifeAttack()">Knife attack · risk injury</button>':''}<button class="btn" onclick="combatHeal()">Treat injury</button><button class="btn" onclick="reload()">Reload</button><button class="btn" onclick="flee()">Retreat</button><button class="btn" onclick="wardResolveFalseEncounter('hold')">Hold and observe</button></div>`);document.querySelector('#m .mh button')?.remove();fightPresentation();}
wardFalseEncounter=function(){if(!S||S.hp<=0||S.f.dead)return false;if(S.room==='wardnorth'&&WW.windowState().triggered&&!WW.windowState().resolved||S.room==='eastcorridor'&&S.f.sprinklerTriggered&&!S.f.sprinklerStopped)return false;if(S.f.falseEncounterSeen||alive(S.room)||S.f.pursuerEncounter||S.f.hidingRoom||(S.pursuer?.active&&S.pursuer.room===S.room))return false;S.f.falseEncounterSeen=1;S.f.falseEncounterActive=1;S.hallCombat={room:S.room,hp:16,turns:0,expires:S.t+9,deadline:Date.now()+25000};hallCombat();return true;};
wardResolveFalseEncounter=function(choice){if(!WW.hallActive())return;if(choice==='fire')return shoot();if(choice==='run')return flee();advanceTime(2);S.hallCombat.turns++;if(S.hallCombat.turns>=3)return WW.resolveHall('wait');hallCombat('It swipes close enough to make me recoil. I cannot judge the distance.');};
combat=function(note){if(WW.hallActive())return hallCombat(note);const r=combatBase(note);fightPresentation();const actions=document.querySelector('#m .c1-encounter-actions');if(actions){const b=document.createElement('button');b.className='btn';b.textContent='Hold and observe';b.onclick=()=>{advanceTime(2);foe('I hesitate. It reaches for me.');};actions.append(b);}return r;};
shoot=function(){if(!WW.hallActive())return shootBase();const w=W[S.eq];if(!w||!has(S.eq)||!(S.ld[S.eq]>0))return hallCombat('Click. I need to reload or retreat.');S.ld[S.eq]--;soundEffect('shot');noise();advanceTime(1);S.hallCombat.turns++;const hit=rnd()<w.hit;if(hit)S.hallCombat.hp-=w.dmg[0]+Math.floor(rnd()*(w.dmg[1]-w.dmg[0]+1));if(S.hallCombat.hp<=0||S.t>=S.hallCombat.expires)return WW.resolveHall('damage');hallCombat(hit?'It recoils from the impact, then reaches again.':'The shot cracks against the wall. It keeps coming.');};
wardSteadyShot=function(){if(WW.hallActive()){advanceTime(1);return shoot();}if(!W[S.eq]||!has(S.eq)||!(S.ld[S.eq]>0))return combat('The chamber is empty.');S.f.steadyAim=true;advanceTime(2);if(alive(S.room))shoot();};
knifeAttack=function(){if(!WW.hallActive())return meleeBase();if(!has('Utility Knife'))return wardResolveFalseEncounter('hold');S.hallCombat.hp-=5;advanceTime(1);if(S.hallCombat.hp<=0)return WW.resolveHall('damage');hallCombat('The blade meets resistance. The orderly stumbles, then straightens.');};
reload=function(){if(!WW.hallActive())return reloadBase();const w=W[S.eq];if(!w||!has(S.eq))return hallCombat('No firearm is equipped.');const amount=Math.min(w.mag-(S.ld[S.eq]||0),cnt(w.ammo));if(amount<=0)return hallCombat('No usable reserve rounds.');rem(w.ammo,amount);S.ld[S.eq]=(S.ld[S.eq]||0)+amount;advanceTime(1);soundEffect('reload');hallCombat('The magazine clicks into place.');};
foe=function(note){if(WW.hallActive())return hallCombat(note);return foeBase(note);};
flee=function(){if(!WW.hallActive())return fleeBase();const from=S.room,target=edges(from).find(r=>r===S.prev)||edges(from)[0];WW.resolveHall('retreat');if(target)go(target,true);};
wardStruggle=function(){if(WW.hallActive())return WW.resolveHall('retreat');const a=actorAt();if(!a)return;const damage=Math.max(3,Math.round(6*S.m));S.hp=Math.max(0,S.hp-damage);if(S.hp<=0)return die();a.down=true;cm=0;S.stag=0;$('m').innerHTML='';advanceTime(2);soundEffect('hit');project();render();const plane=document.querySelector(S.sceneView==='rear'?'.c1-reverse-plane':'.c1-plane');if(plane){const fallen=document.createElement('img');fallen.className='winter-falling-enemy';const visual=WW.enemyVisual?.(a);fallen.src=WW.asset(visual?.still||(!visual?.sheet&&visual?.image)||'assets/characters/'+a.type+'.png');fallen.alt='The infected falls';plane.append(fallen);const removeFallen=()=>{if(WW.isPaused?.())return setTimeout(removeFallen,100);fallen.remove();};setTimeout(removeFallen,1100);}interaction('I wrench free and knock it down. It is still alive. I was hurt, but can leave now.');const to=WW.pendingExit;WW.pendingExit=null;if(to){const leave=()=>{if(WW.isPaused?.())return setTimeout(leave,100);if(S.hp>0&&!S.f.dead&&S.room===a.room)go(to,true);};setTimeout(leave,550);}};
const xEncounter=pursuerEncounter;pursuerEncounter=function(){const r=xEncounter();if(r)fightPresentation();return r;};
const goBase=go;go=function(to,confirmed=false){const edge=WardNavigation.edge(S.room,to);if(!edge)return;if(alive(S.room)&&!confirmed&&to!==S.prev&&(doorOpen(edge)||(D[edge].need&&has(D[edge].need)))){WW.pendingExit=to;return modal('The infected blocks the passage','<p>It is between me and that door. I can fight, or force an opening and risk injury.</p><button class="btn p" onclick="combat()">Face the infected</button><button class="btn" onclick="wardStruggle()">Struggle past · risk injury</button><button class="btn" onclick="WardWinter.pendingExit=null;closeModal()">Stay here</button>');}const result=goBase(to,confirmed);capture();project();return result;};
// Composure recovery does not erase a witnessed incident. Eligibility therefore
// uses both current sanity and saved, one-time trauma flags, so two major shocks
// can produce one earned imaginary encounter without making every room hostile.
WW.incidentStress=()=>S?(S.f.doctorWallSeen?14:0)+(S.f.researcherLastRoomSeen?10:0)+(S.f.plexiIncidentSeen?18:0)+(S.f.beggingPatientChoice==='killed'?17:S.f.beggingPatientChoice?4:0):0;
WW.sanityEpisode=function(){
 if(!S||S.hp<=0||S.f.dead||S.f.chapter1Complete||WW.hallActive()||alive(S.room)||S.f.pursuerEncounter||(S.pursuer?.active&&S.pursuer.room===S.room)||S.f.hidingRoom||SAFE_FROM_PURSUER.has(S.room)||$('m').children.length||WW.isSurvivalPaused?.())return false;
 if(S.room==='wardnorth'&&WW.windowState().triggered&&!WW.windowState().resolved||S.room==='eastcorridor'&&S.f.sprinklerTriggered&&!S.f.sprinklerStopped)return false;
 const stress=WW.incidentStress();
 if(!S.f.falseEncounterSeen&&((stress>=24&&S.san<85)||(S.san<55&&stress>0)))return wardFalseEncounter();
 const count=S.f.visualEpisodes||0;
 if(stress>=10&&S.san<90&&count<2&&!S.sceneDisturbance&&(!count||S.t>=(S.f.nextVisualEpisodeAt||0))){
  S.f.visualEpisodes=count+1;S.f.nextVisualEpisodeAt=S.t+45;
  S.sceneDisturbance={room:S.room,kind:count===0?'hanged':'body',deadline:Date.now()+15000};
  if(S.roomView!=='rear'&&!S.contextThought?.requirement)WW.think?.('I heard movement behind me.');
  renderScene();return true;
 }
 return false;
};
const arrive=chapterArrival;chapterArrival=function(from,to){const result=arrive(from,to);if(result)return result;return WW.sanityEpisode();};
setInterval(()=>{if(WW.isPaused?.()||!S||S.hp<=0||S.f.dead||S.f.chapter1Complete)return;if(WW.hallActive()&&Date.now()>=S.hallCombat.deadline)WW.resolveHall('wait');if(S.sceneDisturbance&&Date.now()>S.sceneDisturbance.deadline){S.sceneDisturbance=null;renderScene();}},350);
})();

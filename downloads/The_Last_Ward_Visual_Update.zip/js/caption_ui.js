/* Fixed, non-scrolling narration cards. Long text advances in readable pages. */
(function(){'use strict';
const WW=WardWinter,source=$('rd'),block=document.querySelector('.narration-block'),thought=$('sceneThoughtText');
const display=document.createElement('p');display.id='captionText';display.setAttribute('aria-live','polite');const controls=document.createElement('div');controls.className='caption-controls';controls.innerHTML='<button type="button" aria-label="Previous narration page">‹</button><span></span><button type="button" aria-label="Next narration page">›</button><button type="button" class="caption-room">Room description</button>';block.append(display,controls);
let room=null,mode='room',text='',pages=[],page=0,roomText='',feedback='';
function wrap(value,width,lines){const ctx=document.createElement('canvas').getContext('2d'),style=getComputedStyle(display);ctx.font=style.font;const rows=[];for(const paragraph of String(value).split('\n')){let line='';for(const word of paragraph.split(/\s+/).filter(Boolean)){const next=line?line+' '+word:word;if(line&&ctx.measureText(next).width>width){rows.push(line);line=word;}else line=next;}if(line)rows.push(line);}const result=[];for(let i=0;i<rows.length;i+=lines)result.push(rows.slice(i,i+lines).join('\n'));return result.length?result:[''];}
function paint(){if(!S)return;const style=getComputedStyle(display),lineHeight=parseFloat(style.lineHeight)||24,width=display.clientWidth||block.clientWidth-40,height=block.clientHeight-parseFloat(getComputedStyle(block).paddingTop)-parseFloat(getComputedStyle(block).paddingBottom),full=wrap(text,width,Math.max(1,Math.floor((height-(mode==='feedback'?24:0))/lineHeight)));pages=full.length===1?full:wrap(text,width,Math.max(1,Math.floor((height-24)/lineHeight)));page=Math.min(page,pages.length-1);display.textContent=pages[page];controls.hidden=pages.length===1&&mode==='room';const buttons=controls.querySelectorAll('button');buttons[0].hidden=buttons[1].hidden=pages.length===1;buttons[0].disabled=page===0;buttons[1].disabled=page>=pages.length-1;controls.querySelector('span').textContent=pages.length>1?(page+1)+' / '+pages.length:'';buttons[2].hidden=mode==='room';display.dataset.fullText=text;}
function sync(){if(!S)return;roomText=source.textContent.trim();if(room!==S.room){room=S.room;mode='room';feedback='';page=0;}const next=mode==='room'?roomText:feedback;if(next!==text){text=next;page=0;}paint();}
function show(value){if(!S)return;room=S.room;feedback=String(value||'').trim();mode=feedback?'feedback':'room';text=mode==='feedback'?feedback:source.textContent.trim();page=0;paint();}
controls.querySelectorAll('button')[0].onclick=()=>{page=Math.max(0,page-1);paint();};controls.querySelectorAll('button')[1].onclick=()=>{page=Math.min(pages.length-1,page+1);paint();};controls.querySelectorAll('button')[2].onclick=()=>{mode='room';text=source.textContent.trim();page=0;paint();};
const interactionBase=interaction;interaction=function(value){interactionBase(value);show(value);};new MutationObserver(sync).observe(source,{childList:true,characterData:true,subtree:true});new ResizeObserver(paint).observe(block);WW.caption={sync,show,get pages(){return pages.slice();}};

const thoughtBlock=document.querySelector('.scene-thought'),thoughtDisplay=document.createElement('p'),thoughtControls=document.createElement('div');thoughtDisplay.id='thoughtCaptionText';thoughtControls.id='thoughtCaptionControls';thoughtControls.className='caption-controls';thoughtControls.innerHTML='<button type="button" onclick="WardWinter.readCurrentThought()">Read in Journal</button>';thoughtBlock.append(thoughtDisplay,thoughtControls);let thoughtText='';
function paintThought(){if(!S)return;const value=thought.textContent.trim();if(value!==thoughtText){thoughtText=value;S.thoughtHistory=S.thoughtHistory||[];if(value&&!S.thoughtHistory.some(v=>v.text===value)){S.thoughtHistory.push({room:S.room,text:value});S.thoughtHistory=S.thoughtHistory.slice(-40);}}
 const font=getComputedStyle(thoughtDisplay),line=parseFloat(font.lineHeight)||24,style=getComputedStyle(thoughtBlock),label=thoughtBlock.querySelector(':scope>span'),labelStyle=getComputedStyle(label);
 const available=thoughtBlock.clientHeight-parseFloat(style.paddingTop)-parseFloat(style.paddingBottom)-label.getBoundingClientRect().height-(parseFloat(labelStyle.marginTop)||0)-(parseFloat(labelStyle.marginBottom)||0);
 function fits(candidate,height){thoughtDisplay.textContent=candidate;return thoughtDisplay.getBoundingClientRect().height<=height+1&&thoughtDisplay.scrollHeight<=height+1;}
 thoughtControls.hidden=true;
 if(fits(value,available)){thoughtDisplay.dataset.fullText=value;return;}
 thoughtControls.hidden=false;const room=Math.max(line,available-thoughtControls.getBoundingClientRect().height);
 const sentences=value.match(/[^.!?]+[.!?]+(?:[”’"']|$)?|[^.!?]+$/g)||[value];let brief=sentences[0]?.trim()||value;
 for(let i=1;i<sentences.length;i++){const next=brief+' '+sentences[i].trim();if(!fits(next,room))break;brief=next;}
 while(!fits(brief,room)&&brief.includes(' '))brief=brief.slice(0,brief.lastIndexOf(' ')).replace(/[.…]+$/,'')+'…';
 thoughtDisplay.textContent=brief;thoughtDisplay.dataset.fullText=value;
}
WW.readCurrentThought=()=>WW.readRecord?.('Current thought',thoughtText,{journal:true});new MutationObserver(paintThought).observe(thought,{childList:true,characterData:true,subtree:true});new ResizeObserver(paintThought).observe(thoughtBlock);

const base=render;render=function(){const value=base();sync();paintThought();return value;};
})();

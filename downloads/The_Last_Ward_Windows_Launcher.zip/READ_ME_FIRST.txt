THE LAST WARD - WINDOWS LAUNCHER FIX

Extract START_GAME.exe and START_GAME.bat into your existing extracted game folder, beside index.html.
Double-click START_GAME.exe. Keep its window open while playing.
No Python or internet connection is needed.
Do not open index.html directly. Keep all original asset folders in place.
Requires Windows 10/11 x64-compatible and a modern WebGL browser.
